# plugin name

ppx-plugin-manager用のプラグインです。  

## インストール

\_pluginlist

```text
remote ''
```

